'use client';
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Plus, Edit2, Trash2, X, Calendar, MapPin, Users } from 'lucide-react';
import { EventUnifiedSchema } from '@/lib/validations';
import { Pagination } from '@/components/ui/Pagination';
import Popup from '../ui/Popup';
import { z } from 'zod';

const LIMIT = 10;
const EVENT_TYPES = ['general', 'sankalp', 'workshop', 'hackathon'] as const;
const STATUSES = ['upcoming', 'completed'] as const;

const AdminEvents = () => {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [popup, setPopup] = useState({ show: false, type: 'success' as const, message: '', isConfirm: false, onConfirm: () => {} });

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm({
    resolver: zodResolver(EventUnifiedSchema),
    defaultValues: { eventType: 'general', status: 'upcoming', capacity: 100 } as any,
  });

  const eventType = watch('eventType');

  const { data, isLoading } = useQuery({
    queryKey: ['adminEvents', page],
    queryFn: async () => { const res = await fetch(`/api/event?page=${page}&limit=${LIMIT}`); return res.json(); },
  });

  const events = data?.data ?? [];
  const pagination = data?.pagination;

  const saveEvent = useMutation({
    mutationFn: async ({ formData, id }: { formData: FormData; id: string | null }) => {
      const url = id ? `/api/event/${id}` : '/api/event';
      const res = await fetch(url, { method: id ? 'PUT' : 'POST', body: formData });
      if (!res.ok) { const err = await res.json(); throw new Error(err.message); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminEvents'] });
      setShowModal(false); reset(); setPhotoFiles([]); setEditId(null);
      setPopup({ show: true, type: 'success', message: editId ? 'Event updated!' : 'Event created!', isConfirm: false, onConfirm: () => {} });
    },
    onError: (err: any) => setPopup({ show: true, type: 'success', message: err.message, isConfirm: false, onConfirm: () => {} }),
  });

  const deleteEvent = useMutation({
    mutationFn: async (id: string) => { const res = await fetch(`/api/event/${id}`, { method: 'DELETE' }); if (!res.ok) throw new Error('Delete failed'); return res.json(); },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['adminEvents'] }),
  });

  const onSubmit = (data: any) => {
    const fd = new FormData();
    Object.entries(data).forEach(([k, v]) => { if (v !== undefined && v !== null) fd.append(k, String(v)); });
    photoFiles.forEach(f => fd.append('photos', f));
    saveEvent.mutate({ formData: fd, id: editId });
  };

  const openAdd = () => { reset({ eventType: 'general', status: 'upcoming', capacity: 100 } as any); setEditId(null); setPhotoFiles([]); setShowModal(true); };
  const openEdit = (ev: any) => { setEditId(ev.id); reset(ev); setShowModal(true); };
  const confirmDelete = (id: string, name: string) => setPopup({ show: true, type: 'success', message: `Delete "${name}"?`, isConfirm: true, onConfirm: () => { deleteEvent.mutate(id); setPopup(p => ({ ...p, show: false })); } });

  const inputClass = (hasError: boolean) => `w-full bg-white/5 border rounded-xl px-4 py-3 text-white text-sm focus:outline-none transition-all ${hasError ? 'border-red-500/50' : 'border-white/10 focus:border-white/20'}`;

  if (isLoading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Events <span className="text-neutral-500 text-sm font-normal ml-2">({pagination?.total ?? 0})</span></h2>
        <button onClick={openAdd} className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-xl font-semibold text-sm hover:bg-neutral-200 transition-all">
          <Plus className="w-4 h-4" /> Add Event
        </button>
      </div>

      <div className="space-y-3">
        {events.map((ev: any) => (
          <div key={ev.id} className="bg-white/[0.03] border border-white/10 rounded-2xl p-4 flex items-center justify-between gap-4 hover:border-white/20 transition-all">
            <div className="flex items-center gap-4 min-w-0">
              {ev.images?.[0] && <img src={ev.images[0].imageUrl} alt="" className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />}
              <div className="min-w-0">
                <p className="text-white font-semibold text-sm truncate">{ev.name}</p>
                <div className="flex flex-wrap gap-3 text-neutral-500 text-xs mt-1">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{new Date(ev.eventDate).toLocaleDateString('en-IN')}</span>
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{ev.venue}</span>
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />Cap: {ev.capacity}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase ${ev.status === 'upcoming' ? 'bg-blue-500/20 text-blue-400' : 'bg-neutral-700/50 text-neutral-400'}`}>{ev.status}</span>
              <span className="px-2 py-1 rounded-lg bg-white/5 text-neutral-400 text-[10px] uppercase">{ev.eventType}</span>
              <button onClick={() => openEdit(ev)} className="p-2 text-neutral-400 hover:text-white hover:bg-white/10 rounded-lg transition-all"><Edit2 className="w-4 h-4" /></button>
              <button onClick={() => confirmDelete(ev.id, ev.name)} className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
        {events.length === 0 && <p className="text-neutral-500 text-center py-16">No events yet.</p>}
      </div>

      {pagination && <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} limit={pagination.limit} onPageChange={setPage} />}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] border border-white/10 rounded-3xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white">{editId ? 'Edit Event' : 'Create Event'}</h3>
              <button onClick={() => setShowModal(false)} className="p-2 text-neutral-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Event Name</label><input className={inputClass(!!errors.name)} {...register('name')} />{errors.name && <p className="text-red-400 text-xs mt-1">{(errors.name as any)?.message}</p>}</div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Venue</label><input className={inputClass(!!errors.venue)} {...register('venue')} />{errors.venue && <p className="text-red-400 text-xs mt-1">{(errors.venue as any)?.message}</p>}</div>
              </div>
              <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Description</label><textarea rows={3} className={inputClass(!!errors.description) + ' resize-none'} {...register('description')} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Event Date</label><input type="datetime-local" className={inputClass(!!errors.eventDate)} {...register('eventDate')} /></div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Start Time</label><input type="datetime-local" className={inputClass(!!errors.startTime)} {...register('startTime')} /></div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">End Time</label><input type="datetime-local" className={inputClass(!!errors.endTime)} {...register('endTime')} /></div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Registration Closes</label><input type="datetime-local" className={inputClass(!!errors.registrationCloseAt)} {...register('registrationCloseAt')} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Type</label><select className={inputClass(false)} {...register('eventType')}>{EVENT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Status</label><select className={inputClass(false)} {...register('status')}>{STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Capacity</label><input type="number" className={inputClass(!!errors.capacity)} {...register('capacity', { valueAsNumber: true })} /></div>
                {(eventType === 'hackathon') && <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Max Team Size</label><input type="number" className={inputClass(false)} {...register('maxTeamSize', { valueAsNumber: true })} /></div>}
              </div>
              {(eventType === 'sankalp' || eventType === 'hackathon' || eventType === 'workshop') && (
                <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Rules</label><textarea rows={3} className={inputClass(false) + ' resize-none'} {...register('rules' as any)} /></div>
              )}
              <div><label className="text-[10px] uppercase tracking-widest text-neutral-500 font-black block mb-1">Photos</label>
                <input type="file" multiple accept="image/*" className="w-full text-neutral-400 text-sm" onChange={e => setPhotoFiles(Array.from(e.target.files ?? []))} />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-3 border border-white/10 rounded-xl text-neutral-400 hover:text-white transition-all text-sm">Cancel</button>
                <button type="submit" disabled={saveEvent.isPending} className="flex-1 py-3 bg-white text-black rounded-xl font-semibold text-sm hover:bg-neutral-200 transition-all disabled:opacity-50">
                  {saveEvent.isPending ? 'Saving...' : editId ? 'Update Event' : 'Create Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Popup show={popup.show} type={popup.type} message={popup.message} isConfirm={popup.isConfirm} onConfirm={popup.onConfirm} onClose={() => setPopup(p => ({ ...p, show: false }))} />
    </div>
  );
};

export default AdminEvents;