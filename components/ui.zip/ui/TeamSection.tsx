"use client";

import { motion } from "framer-motion";
import MemberCard from "./MemberCard";
import type { Member } from "@/data/initial-members";

interface TeamSectionProps {
  title: string;
  color?: string;
  members: Member[];
}

export default function TeamSection({
  title,
  color = "#8B5CF6",
  members,
}: TeamSectionProps) {
  if (members.length === 0) return null;

  return (
    <section className="mb-24">
      {/* Section Heading */}
      <motion.div
        initial={{ opacity: 0, x: -25 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="flex items-center gap-4 mb-12"
      >
        <span
          className="w-3 h-3 rounded-full"
          style={{ backgroundColor: color }}
        />

        <h2
          className="uppercase tracking-[0.35em] text-lg font-medium"
          style={{ color }}
        >
          {title}
        </h2>
      </motion.div>

      {/* Cards */}
      <div className="grid gap-10 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {members.map((member) => (
          <MemberCard
            key={member.id}
            member={member}
          />
        ))}
      </div>
    </section>
  );
}